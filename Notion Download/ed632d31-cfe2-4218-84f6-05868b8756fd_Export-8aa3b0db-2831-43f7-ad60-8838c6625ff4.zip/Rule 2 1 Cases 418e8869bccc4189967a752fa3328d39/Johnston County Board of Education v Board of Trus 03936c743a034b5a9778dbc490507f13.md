# Johnston County Board of Education v. Board of Trustees, Teachers' and State Employees' Retirement System

Cite: 817 S.E.2d 922, 922
Court: N.C.App.
Issued Date: Sep. 18, 2018
Reviewed: Yes

922: “The other three Boards of Education also petitioned, separately, for judicial review and, along with petitions of review from denials of requests for declaratory rulings by the Division, filed separately by all four of the above named Boards of Education, this case was designated “exceptional” pursuant to [Rule 2.1 of the General Rules of Practice](https://1.next.westlaw.com/Link/Document/FullText?findType=L&pubNum=1008947&cite=NCRSUPDR2.1&originatingDoc=I8e2f1600bb6d11e8b93ad6f77bf99296&refType=LQ&originationContext=document&transitionType=DocumentItem&ppcid=46bb2e1ab73f4607a8af0b24d7f536d0&contextData=(sc.UserEnteredCitation)) for the Superior Courts. Venue was transferred to Wake County, and Judge James E. Hardin, Jr. was assigned to hear all eight cases, including the present case.” 

992, Footnote 2: “The eight cases heard by Judge Hardin, now before us on appeal, are COA17-1017, COA17-1018, COA17-1019, COA17-1020, COA17-1021, COA17-1022, COA17-1023, and COA17-1024.”

No Related filings cite 2.1

No record available

No Analysis of Rule 2.1

THEORY: Facts of case do not exactly match up with an enumerated factor, could possibly be because some of the parties are Boards of Education.