# Boyce v. North Carolina State Bar

Cite: 814 S.E.2d 127, 130
Court: N.C.App.
Issued Date: Apr. 03, 2018
Reviewed: Yes

130: “Chief Justice Lake of the North Carolina Supreme Court designated this action as exceptional, pursuant to [Rule 2.1 of the General Rules of Practice](https://1.next.westlaw.com/Link/Document/FullText?findType=L&pubNum=1008947&cite=NCRSUPDR2.1&originatingDoc=I213310b0375611e8a054a06708233710&refType=LQ&originationContext=document&transitionType=DocumentItem&ppcid=a6bd149fcb65454bafdf6dfa8d1649fd&contextData=(sc.Search)). *[Id.* at 573, 611 **S.E**.**2d** at 176](https://1.next.westlaw.com/Link/Document/FullText?findType=Y&serNum=2006420625&pubNum=0000711&originatingDoc=I213310b0375611e8a054a06708233710&refType=RP&fi=co_pp_sp_711_176&originationContext=document&transitionType=DocumentItem&ppcid=a6bd149fcb65454bafdf6dfa8d1649fd&contextData=(sc.Search)#co_pp_sp_711_176). Chief Justice Lake assigned Superior Court Judge John B. Lewis, Jr., (“Judge Lewis”) to the action.”

No related filings cite Rule 2.1

No record available on Westlaw

No Analysis of Rule 2.1

SUMMARY: Member of law firm filed declaratory action on basis that NC Bar failed to discipline a candidate for Atty General who made false statements in political ads

THEORY: Frankly I think this case was designated because suing the State Bar is a big deal.