# Wilkes County Board of Education v. Board of Trustees, Teachers' and State Employees' Retirement System

Cite: 818 S.E.2d 202, 202
Court: N.C.App.
Issued Date: Sep. 18, 2018
Reviewed: Yes

202: “The other three Boards of Education also petitioned, separately, for judicial review and, along with petitions of review from denials of requests for declaratory rulings by the Division, filed separately by all four of the above named Boards of Education, this case was designated “exceptional” pursuant to [Rule 2.1 of the General Rules of Practice](https://1.next.westlaw.com/Link/Document/FullText?findType=L&pubNum=1008947&cite=NCRSUPDR2.1&originatingDoc=Ie09b1030bb7011e8b93ad6f77bf99296&refType=LQ&originationContext=document&transitionType=DocumentItem&ppcid=26b4d1a8d30e431d9f9ac719144bb555&contextData=(sc.UserEnteredCitation)) for the Superior Courts. Venue was transferred to Wake County, and Judge James E. Hardin, Jr. was assigned to hear all eight cases, including the present case.” (SAME AS 817 S.E.2d 922, 817 S.E.2d 924, and 818 S.E.2d 201)

No related filings cite Rule 2.1

No Record on Westlaw

No Analysis of Rule 2.1

THEORY: Designated because School Board is a party, relation to the other School Board Cases, promote judicial efficiency