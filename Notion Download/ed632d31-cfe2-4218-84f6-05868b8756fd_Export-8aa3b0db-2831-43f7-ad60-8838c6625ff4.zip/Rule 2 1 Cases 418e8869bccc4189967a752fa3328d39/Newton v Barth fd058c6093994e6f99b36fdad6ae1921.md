# Newton v. Barth

Cite: 788 S.E.2d 653, 658
Court: N.C.App.
Issued Date: July 19, 2016
Reviewed: Yes

658: “On 11 July and 19 August 2014, our Supreme Court's Chief Justice entered separate orders designating these cases as exceptional pursuant to [Rule 2.1 of the General Rules of Practice for the Superior and District Courts](https://1.next.westlaw.com/Link/Document/FullText?findType=L&pubNum=1008947&cite=NCRSUPDR2.1&originatingDoc=I6e1f54ee4e0c11e6b86bd602cb8781fa&refType=LQ&originationContext=document&transitionType=DocumentItem&ppcid=e6903bb294cc4f1199a2f64bbf34928e&contextData=(sc.Search)).” 

No relevant filings cite Rule 2.1

No Record on Westlaw

No Analysis of Rule 2.1

SUMMARY: Customers/Suppliers/Vendors of a company in bankruptcy sue the former president (and his father) for deceptive trade practices and fraud.

THEORY: Designated because of complications with bankruptcy, could also be the large amount of parties/Diverse interests of parties.