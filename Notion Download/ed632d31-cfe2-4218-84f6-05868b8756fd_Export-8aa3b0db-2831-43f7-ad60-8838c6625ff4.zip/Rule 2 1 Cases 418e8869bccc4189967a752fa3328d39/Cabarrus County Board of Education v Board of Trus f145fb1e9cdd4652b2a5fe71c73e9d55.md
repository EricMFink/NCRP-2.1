# Cabarrus County Board of Education v. Board of Trustees, Teachers' and State Employees' Retirement System

Cite: 818 S.E.2d 201, 201
Court: N.C.App.
Issued Date: Sep. 18, 2018
Reviewed: Yes

201: “The other three Boards of Education also petitioned, separately, for judicial review and, along with petitions of review from denials of requests for declaratory rulings by the Division, filed separately by all four of the above named Boards of Education, this case was designated “exceptional” pursuant to [Rule 2.1 of the General Rules of Practice](https://1.next.westlaw.com/Link/Document/FullText?findType=L&pubNum=1008947&cite=NCRSUPDR2.1&originatingDoc=I7e99acf0bb6d11e8ae6bb4b0ae8dca5a&refType=LQ&originationContext=document&transitionType=DocumentItem&ppcid=e2b5e365470a4fb39ec7a630190bd455&contextData=(sc.UserEnteredCitation)) for the Superior Courts. Venue was transferred to Wake County and Judge James E. Hardin, Jr. was assigned to hear all eight cases, including the present case.” (SAME AS 817 S.E.2d 922 and 817 S.E.2d 924)

No related filings cite Rule 2.1

No Record on Westlaw

No Analysis of Rule 2.1

THEORY: Status as school board and related cases, promote judicial efficiency