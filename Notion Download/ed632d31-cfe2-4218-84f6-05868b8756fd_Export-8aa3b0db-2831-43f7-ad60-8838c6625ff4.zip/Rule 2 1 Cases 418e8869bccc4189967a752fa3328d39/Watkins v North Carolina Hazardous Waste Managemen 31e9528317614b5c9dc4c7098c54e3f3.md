# Watkins v. North Carolina Hazardous Waste Management Com'n Granville County

Cite: 397 S.E.2d 78, 79
Court: N.C.
Issued Date: Sep. 25, 1990
Reviewed: Yes

If there is a case attached to this order, I cannot find it on Westlaw

SUMMARY: This is an order designating this case as Exceptional and assigning it to Judge Battle. Based on the dates, parties, and judge assigned, I believe this case is part of a larger nexus involving the two cases immediately prior to this in the list. There is no reference to what factors this case was designated under in the order.

THEORY: I cannot make a sound theory without the opinion. But based on the three cases now against NC Hazardous Waste… in a row, it is possible this case was designated to promote the efficient administration of justice.