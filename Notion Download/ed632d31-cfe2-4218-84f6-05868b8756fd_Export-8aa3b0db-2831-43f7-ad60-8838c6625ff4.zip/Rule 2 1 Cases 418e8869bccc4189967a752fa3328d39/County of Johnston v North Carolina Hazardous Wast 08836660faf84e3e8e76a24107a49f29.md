# County of Johnston v. North Carolina Hazardous Waste Management Com'n Johnson County File No. 90CVD1930

Cite: 398 S.E.2d 870, 870
Court: N.C.
Issued Date: Nov. 28, 1990
Reviewed: Yes

If there is a case attached to this order, I cannot find it on Westlaw

SUMMARY: This is an order designating the case as exceptional and assigning it to Judge Battle. There is no reference to what factors this case is designated under in the order. 

THEORY: I cannot make a sound guess as to what factors this case was designated under without the case opinion which I have yet to find.