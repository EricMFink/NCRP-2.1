# Combs v. North Carolina Hazardous Waste Management Com'n

Cite: 399 S.E.2d 134, 134
Court: N.C.
Issued Date: Nov. 16, 1990
Reviewed: Yes

If there is a case attached to this, I cannot find it on Westlaw

SUMMARY: This is an order designating the case as exceptional and appointing Judge Battle. Based on the date, court, and the parties involved I think this case may have relation to *************************************************County of Johnston v. North Carolina Hazardous Waste…************************************************* (the case right above this) There is no reference to what factors this case was designated under in the order.

THEORY: I cannot make a sound guess regarding the factors without the case opinion.